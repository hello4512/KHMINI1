package text.com.kh.test.run;

import text.com.kh.test.view.MainFrame;

public class Run {

	public static void main(String[] args) {
		
		// LoginAfterPage lap = new LoginAfterPage();
		// ManagerPage mp = new ManagerPage();
		new MainFrame();
	}

}
